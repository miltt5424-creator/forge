import { c as startOfWeek, n as subWeeks, u as addDays } from "../_libs/date-fns.mjs";
import { d as toKey, f as todayKey, p as useForgeStore, r as cn, u as lastNKeysIncludingToday } from "./store-KYc58Jhg.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bits-CgkpcfD3.js
var import_jsx_runtime = require_jsx_runtime();
function activeHabits(habits) {
	return habits.filter((h) => !h.paused);
}
function coreHabits(habits) {
	return activeHabits(habits).filter((h) => h.tier === "core").sort((a, b) => a.rank - b.rank);
}
function secondaryHabits(habits) {
	return activeHabits(habits).filter((h) => h.tier === "secondary").sort((a, b) => a.rank - b.rank);
}
function sortedHabits(habits) {
	return [...habits].sort((a, b) => {
		if (a.paused !== b.paused) return a.paused ? 1 : -1;
		if (a.tier !== b.tier) return a.tier === "core" ? -1 : 1;
		return a.rank - b.rank;
	});
}
function scoreDay(date, habits, mornings, evenings, startedAt) {
	const empty = {
		date,
		committed: 0,
		done: 0,
		coreCommitted: 0,
		coreDone: 0,
		closed: false,
		ratio: null,
		coreRatio: null
	};
	if (startedAt && date < startedAt) return empty;
	const morning = mornings[date];
	const evening = evenings[date];
	const habitById = new Map(habits.map((h) => [h.id, h]));
	const focusIds = morning?.habitIds ?? [];
	const coreIds = habits.filter((h) => h.tier === "core" && !h.paused && h.createdAt.slice(0, 10) <= date).map((h) => h.id);
	const committedIds = focusIds.filter((id) => habitById.has(id));
	const coreInFocus = committedIds.filter((id) => habitById.get(id)?.tier === "core");
	if (!evening) {
		const isPast = date < todayKey();
		if (!morning && !isPast) return empty;
		if (isPast && (morning || coreIds.length > 0)) {
			const coreCommitted = morning ? coreInFocus.length : coreIds.length;
			return {
				date,
				committed: morning ? committedIds.length : coreIds.length,
				done: 0,
				coreCommitted,
				coreDone: 0,
				closed: false,
				ratio: (morning ? committedIds.length : coreIds.length) > 0 ? 0 : null,
				coreRatio: coreCommitted > 0 ? 0 : null
			};
		}
		return empty;
	}
	const done = committedIds.filter((id) => evening.results[id]).length;
	const coreDone = coreInFocus.filter((id) => evening.results[id]).length;
	const committed = committedIds.length;
	const coreCommitted = coreInFocus.length;
	return {
		date,
		committed,
		done,
		coreCommitted,
		coreDone,
		closed: true,
		ratio: committed > 0 ? done / committed : null,
		coreRatio: coreCommitted > 0 ? coreDone / coreCommitted : null
	};
}
function windowScores(days, habits, mornings, evenings, startedAt, includeToday = false) {
	return (includeToday ? lastNKeysIncludingToday(days) : lastNKeysIncludingToday(days + 1).slice(0, -1)).map((date) => scoreDay(date, habits, mornings, evenings, startedAt));
}
function respectPercent(scores, kind) {
	const usable = scores.filter((s) => kind === "core" ? s.coreRatio !== null : s.ratio !== null);
	if (usable.length === 0) return null;
	const total = usable.reduce((acc, s) => {
		if (kind === "core") return acc + s.coreDone / Math.max(1, s.coreCommitted);
		return acc + s.done / Math.max(1, s.committed);
	}, 0);
	return Math.round(total / usable.length * 100);
}
function heldDays(scores) {
	const usable = scores.filter((s) => s.coreRatio !== null);
	return {
		held: usable.filter((s) => s.coreRatio === 1).length,
		total: usable.length
	};
}
function habitDots(habitId, days, evenings, mornings) {
	return lastNKeysIncludingToday(days).map((date) => {
		const committed = mornings[date]?.habitIds.includes(habitId) ?? false;
		const evening = evenings[date];
		if (!committed) return {
			date,
			state: "idle"
		};
		if (!evening) return {
			date,
			state: date < todayKey() ? "miss" : "pending"
		};
		return {
			date,
			state: evening.results[habitId] ? "done" : "miss"
		};
	});
}
function heatmapCells(weeks, habits, mornings, evenings, startedAt) {
	const today = /* @__PURE__ */ new Date();
	const todayK = todayKey(today);
	const thisMonday = startOfWeek(today, { weekStartsOn: 1 });
	const gridStart = subWeeks(thisMonday, weeks - 1);
	const cells = [];
	for (let i = 0; i < weeks * 7; i++) {
		const date = toKey(addDays(gridStart, i));
		cells.push({
			date,
			inFuture: date > todayK,
			score: scoreDay(date, habits, mornings, evenings, startedAt)
		});
	}
	return cells;
}
function heatLevel(ratio, inFuture, hasData) {
	if (inFuture || !hasData) return 0;
	if (ratio === null) return 0;
	if (ratio === 0) return 1;
	if (ratio < .5) return 2;
	if (ratio < 1) return 3;
	return 4;
}
function PageHeader({ kicker, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-8 flex flex-col gap-3 sm:mb-10 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [kicker && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[0.6875rem] uppercase tracking-[0.18em] text-muted",
				children: kicker
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-medium uppercase tracking-[0.1em] sm:text-4xl",
				children: title
			})]
		}), children]
	});
}
function DispersionWarning() {
	const n = activeHabits(useForgeStore((s) => s.habits)).length;
	if (n < 10) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "rounded-lg bg-card px-4 py-3 text-sm leading-relaxed text-foreground shadow-[var(--shadow-border)]",
		children: [
			"Tu as ",
			n,
			" habitudes actives. Est-ce que ton Standard est encore tenable ?"
		]
	});
}
function HabitDots({ states }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1",
		"aria-hidden": true,
		children: states.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-sm", s.state === "done" && "bg-heat-4", s.state === "miss" && "bg-heat-1", s.state === "pending" && "bg-heat-2", s.state === "idle" && "bg-heat-0") }, s.date))
	});
}
function Percent({ value }) {
	if (value === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-faint",
		children: "—"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "tabular-nums",
		children: [value, "%"]
	});
}
function Surface({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-xl bg-card p-5 shadow-[var(--shadow-border)] sm:p-6", className),
		children
	});
}
//#endregion
export { Surface as a, habitDots as c, heldDays as d, respectPercent as f, windowScores as h, Percent as i, heatLevel as l, sortedHabits as m, HabitDots as n, activeHabits as o, secondaryHabits as p, PageHeader as r, coreHabits as s, DispersionWarning as t, heatmapCells as u };
