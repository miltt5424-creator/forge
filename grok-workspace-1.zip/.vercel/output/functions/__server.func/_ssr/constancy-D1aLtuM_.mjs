import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as formatDayLong, o as formatDayShort, p as useForgeStore, r as cn } from "./store-KYc58Jhg.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Surface, d as heldDays, f as respectPercent, h as windowScores, i as Percent, l as heatLevel, r as PageHeader, u as heatmapCells } from "./bits-CgkpcfD3.mjs";
import { a as CartesianGrid, i as Line, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as LineChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/constancy-D1aLtuM_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LEVEL = [
	"bg-heat-0",
	"bg-heat-1",
	"bg-heat-2",
	"bg-heat-3",
	"bg-heat-4"
];
var DOW = [
	"L",
	"M",
	"M",
	"J",
	"V",
	"S",
	"D"
];
function Heatmap({ habits, mornings, evenings, startedAt, weeks = 13 }) {
	const cells = heatmapCells(weeks, habits, mornings, evenings, startedAt);
	const cols = Math.ceil(cells.length / 7);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col justify-between py-0.5 text-[0.625rem] leading-none text-faint",
				children: DOW.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex h-3 items-center sm:h-3.5",
					children: d
				}, `${d}-${i}`))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid w-full flex-1 gap-1",
				style: {
					gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
					gridTemplateRows: "repeat(7, minmax(0, 1fr))",
					gridAutoFlow: "column"
				},
				children: cells.map((cell) => {
					const ratio = cell.score.coreRatio ?? cell.score.ratio;
					const hasData = ratio !== null;
					const level = heatLevel(ratio, cell.inFuture, hasData);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						title: titleFor(cell.date, cell.score, cell.inFuture),
						className: cn("aspect-square min-h-3 rounded-sm sm:min-h-3.5", LEVEL[level], cell.inFuture && "opacity-30")
					}, cell.date);
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-end gap-1.5 text-[0.625rem] uppercase tracking-[0.14em] text-faint",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Faible" }),
				LEVEL.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-sm", c) }, c)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tenu" })
			]
		})]
	});
}
function titleFor(date, score, inFuture) {
	const label = formatDayLong(date);
	if (inFuture) return label;
	if (score.coreRatio === null && score.ratio === null) return `${label} — pas de donnée`;
	const pct = Math.round((score.coreRatio ?? score.ratio ?? 0) * 100);
	if (!score.closed) return `${label} — ${pct}% (journée non close)`;
	return `${label} — ${pct}% du Standard`;
}
function ConstancyPage() {
	const habits = useForgeStore((s) => s.habits);
	const mornings = useForgeStore((s) => s.mornings);
	const evenings = useForgeStore((s) => s.evenings);
	const startedAt = useForgeStore((s) => s.startedAt);
	const s7 = (0, import_react.useMemo)(() => windowScores(7, habits, mornings, evenings, startedAt), [
		habits,
		mornings,
		evenings,
		startedAt
	]);
	const s30 = (0, import_react.useMemo)(() => windowScores(30, habits, mornings, evenings, startedAt), [
		habits,
		mornings,
		evenings,
		startedAt
	]);
	const s90 = (0, import_react.useMemo)(() => windowScores(90, habits, mornings, evenings, startedAt), [
		habits,
		mornings,
		evenings,
		startedAt
	]);
	const chart = (0, import_react.useMemo)(() => {
		return windowScores(30, habits, mornings, evenings, startedAt, true).map((d) => ({
			date: d.date,
			label: formatDayShort(d.date),
			standard: d.coreRatio === null ? null : Math.round(d.coreRatio * 100),
			focus: d.ratio === null ? null : Math.round(d.ratio * 100)
		}));
	}, [
		habits,
		mornings,
		evenings,
		startedAt
	]);
	const held = heldDays(s30);
	const hasHistory = s30.some((s) => s.coreRatio !== null || s.ratio !== null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl forge-in",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Réalité, pas un score",
				title: "Constance"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2 sm:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "7 jours",
						value: respectPercent(s7, "core")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "30 jours",
						value: respectPercent(s30, "core")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "90 jours",
						value: respectPercent(s90, "core")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted",
				children: ["Pourcentage de respect du Standard — tes piliers, pas tes envies du jour.", held.total > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-foreground tabular-nums",
						children: [
							held.held,
							"/",
							held.total
						]
					}),
					" ",
					"jours intacts sur 30."
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-5 font-display text-sm uppercase tracking-[0.18em] text-muted",
					children: "90 jours"
				}), hasHistory ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heatmap, {
					habits,
					mornings,
					evenings,
					startedAt
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: "La constance se voit ici. Pas demain. Aujourd'hui."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-5 font-display text-sm uppercase tracking-[0.18em] text-muted",
						children: "Régularité · 30 jours"
					}),
					chart.some((d) => d.standard !== null) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-56 w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
								data: chart,
								margin: {
									top: 8,
									right: 8,
									left: -18,
									bottom: 0
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										stroke: "rgba(237,235,230,0.06)",
										vertical: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "label",
										tick: {
											fill: "#5c5a55",
											fontSize: 11
										},
										tickLine: false,
										axisLine: false,
										interval: 4
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										domain: [0, 100],
										tick: {
											fill: "#5c5a55",
											fontSize: 11
										},
										tickLine: false,
										axisLine: false,
										tickFormatter: (v) => `${v}`,
										width: 36
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										contentStyle: {
											background: "#141413",
											border: "1px solid #2a2925",
											borderRadius: 8,
											fontSize: 12,
											color: "#edebe6"
										},
										formatter: (value) => [`${value}%`, ""],
										labelFormatter: (label) => String(label)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
										type: "monotone",
										dataKey: "standard",
										stroke: "#c8c4ba",
										strokeWidth: 1.75,
										dot: false,
										connectNulls: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
										type: "monotone",
										dataKey: "focus",
										stroke: "#7a776f",
										strokeWidth: 1.25,
										dot: false,
										connectNulls: true
									})
								]
							})
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Rien à tracer tant qu'une journée n'est pas close."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-6 text-[0.6875rem] uppercase tracking-[0.14em] text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "h-px w-4 bg-heat-4" }), " Standard"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "h-px w-4 bg-heat-3" }), " Focus"]
						})]
					})
				]
			})
		]
	});
}
function StatCard({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[0.6875rem] uppercase tracking-[0.16em] text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-display text-3xl font-medium tracking-wide sm:text-4xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Percent, { value })
		})]
	});
}
//#endregion
export { ConstancyPage as component };
