import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as CATEGORY_LABEL, p as useForgeStore, r as cn, t as CATEGORIES } from "./store-KYc58Jhg.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Surface, c as habitDots, m as sortedHabits, n as HabitDots, o as activeHabits, r as PageHeader, s as coreHabits, t as DispersionWarning } from "./bits-CgkpcfD3.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { c as Pencil, d as ChevronUp, f as ChevronDown, l as Pause, o as Plus, r as Trash2, s as Play, t as X } from "../_libs/lucide-react.mjs";
import { a as Button, i as Input, n as Textarea, r as Label } from "./router-BVv91lJD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/habits-Dk7Thzf2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-background/80 data-[state=open]:animate-in data-[state=closed]:animate-out", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed z-50 flex flex-col gap-5 bg-card p-6 text-foreground shadow-[var(--shadow-border)] outline-none", "inset-3 overflow-y-auto rounded-xl sm:inset-auto sm:left-1/2 sm:top-1/2 sm:max-h-[min(88dvh,720px)] sm:w-full sm:max-w-lg sm:-translate-x-1/2 sm:-translate-y-1/2", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
			className: "absolute right-3 top-3 flex size-11 items-center justify-center rounded-md text-muted transition-colors hover:text-foreground",
			"aria-label": "Fermer",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
				className: "size-4",
				strokeWidth: 1.75
			})
		})]
	})] });
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-2xl font-medium uppercase tracking-[0.12em]", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm leading-relaxed text-muted", className),
		...props
	});
}
function HabitForm({ initial, onDone, onCancel }) {
	const habits = useForgeStore((s) => s.habits);
	const addHabit = useForgeStore((s) => s.addHabit);
	const updateHabit = useForgeStore((s) => s.updateHabit);
	const [fields, setFields] = (0, import_react.useState)({
		rule: initial?.rule ?? "",
		why: initial?.why ?? "",
		tier: initial?.tier ?? "secondary",
		category: initial?.category ?? "autre"
	});
	const [error, setError] = (0, import_react.useState)(null);
	const cores = coreHabits(habits).length;
	const coreFull = fields.tier === "core" && cores >= 5 && (!initial || initial.tier !== "core" || initial.paused);
	function submit(e) {
		e.preventDefault();
		if (!fields.rule.trim() || !fields.why.trim()) {
			setError("La règle et la raison sont exigées.");
			return;
		}
		if (initial) {
			const res = updateHabit(initial.id, fields);
			if (!res.ok) {
				setError(res.error);
				return;
			}
		} else {
			const res = addHabit(fields);
			if (!res.ok) {
				setError(res.error);
				return;
			}
		}
		onDone();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "habit-rule",
					children: "La règle exacte"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "habit-rule",
					value: fields.rule,
					onChange: (e) => setFields((f) => ({
						...f,
						rule: e.target.value
					})),
					placeholder: "45 min de sport"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "habit-why",
					children: "Pourquoi c'est non-négociable"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "habit-why",
					value: fields.why,
					onChange: (e) => setFields((f) => ({
						...f,
						why: e.target.value
					})),
					placeholder: "Parce que…",
					rows: 3
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "habit-tier",
						children: "Niveau"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "habit-tier",
						value: fields.tier,
						onChange: (e) => setFields((f) => ({
							...f,
							tier: e.target.value
						})),
						className: "flex h-11 w-full rounded-md bg-card-2 px-3 text-sm text-foreground shadow-[var(--shadow-border)] outline-none focus-visible:shadow-[0_0_0_1px_var(--color-ring)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "core",
							children: "Pilier (core)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "secondary",
							children: "Secondaire"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "habit-cat",
						children: "Catégorie"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						id: "habit-cat",
						value: fields.category,
						onChange: (e) => setFields((f) => ({
							...f,
							category: e.target.value
						})),
						className: "flex h-11 w-full rounded-md bg-card-2 px-3 text-sm text-foreground shadow-[var(--shadow-border)] outline-none focus-visible:shadow-[0_0_0_1px_var(--color-ring)]",
						children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c,
							children: CATEGORY_LABEL[c]
						}, c))
					})]
				})]
			}),
			fields.tier === "core" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					cores,
					"/",
					5,
					" piliers actifs. Les piliers restent visibles chaque matin."
				]
			}),
			coreFull && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-foreground",
				children: [
					"Tes piliers sont limités à ",
					5,
					". Pause ou rétrograde-en un avant."
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-foreground",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					onClick: onCancel,
					children: "Annuler"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: coreFull,
					children: initial ? "Enregistrer" : "Ajouter"
				})]
			})
		]
	});
}
function HabitsPage() {
	const habits = useForgeStore((s) => s.habits);
	const evenings = useForgeStore((s) => s.evenings);
	const mornings = useForgeStore((s) => s.mornings);
	const updateHabit = useForgeStore((s) => s.updateHabit);
	const removeHabit = useForgeStore((s) => s.removeHabit);
	const moveHabit = useForgeStore((s) => s.moveHabit);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	const list = (0, import_react.useMemo)(() => {
		let rows = sortedHabits(habits);
		if (filter === "core") rows = rows.filter((h) => h.tier === "core" && !h.paused);
		if (filter === "secondary") rows = rows.filter((h) => h.tier === "secondary" && !h.paused);
		if (filter === "paused") rows = rows.filter((h) => h.paused);
		return rows;
	}, [habits, filter]);
	const grouped = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const h of list) {
			const arr = map.get(h.category) ?? [];
			arr.push(h);
			map.set(h.category, arr);
		}
		return [...map.entries()];
	}, [list]);
	const cores = coreHabits(habits).length;
	const active = activeHabits(habits).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl forge-in",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Ton Standard",
				title: "Habitudes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => {
						setEditing(null);
						setOpen(true);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "size-4",
						strokeWidth: 1.75
					}), "Ajouter"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex flex-wrap items-center gap-4 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-foreground",
							children: cores
						}),
						"/",
						5,
						" piliers"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-faint",
						children: "·"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-foreground",
						children: active
					}), " actives"] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DispersionWarning, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex flex-wrap gap-2",
				children: [
					["all", "Toutes"],
					["core", "Core"],
					["secondary", "Secondaires"],
					["paused", "En pause"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(id),
					className: cn("h-11 rounded-md px-3 text-sm transition-colors duration-150", filter === id ? "bg-accent text-accent-foreground" : "bg-card text-muted shadow-[var(--shadow-border)] hover:text-foreground"),
					children: label
				}, id))
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-12 max-w-md text-sm leading-relaxed text-muted",
				children: filter === "all" ? "Aucun pilier. Ajoute ce que tu refuses de rater — pas ce que tu aimerais faire un jour." : "Rien dans ce filtre."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 space-y-8",
				children: grouped.map(([cat, rows]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-sm uppercase tracking-[0.18em] text-muted",
						children: CATEGORY_LABEL[cat]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: rows.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
							className: "p-4 sm:p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-medium text-foreground",
												children: h.rule
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[0.625rem] uppercase tracking-[0.14em] text-faint",
												children: [h.tier === "core" ? "Pilier" : "Secondaire", h.paused ? " · Pause" : ""]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm leading-relaxed text-muted",
											children: h.why
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HabitDots, { states: habitDots(h.id, 7, evenings, mornings) })
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex shrink-0 flex-col gap-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
										label: "Monter",
										onClick: () => moveHabit(h.id, -1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, {
											className: "size-4",
											strokeWidth: 1.75
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
										label: "Descendre",
										onClick: () => moveHabit(h.id, 1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
											className: "size-4",
											strokeWidth: 1.75
										})
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(IconBtn, {
										label: "Modifier",
										onClick: () => {
											setEditing(h);
											setOpen(true);
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {
											className: "size-3.5",
											strokeWidth: 1.75
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs",
											children: "Modifier"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(IconBtn, {
										label: h.paused ? "Reprendre" : "Mettre en pause",
										onClick: () => updateHabit(h.id, { paused: !h.paused }),
										children: [h.paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
											className: "size-3.5",
											strokeWidth: 1.75
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
											className: "size-3.5",
											strokeWidth: 1.75
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs",
											children: h.paused ? "Reprendre" : "Pause"
										})]
									}),
									confirmId === h.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
										label: "Confirmer la suppression",
										onClick: () => {
											removeHabit(h.id);
											setConfirmId(null);
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-foreground",
											children: "Confirmer"
										})
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(IconBtn, {
										label: "Supprimer",
										onClick: () => setConfirmId(h.id),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
											className: "size-3.5",
											strokeWidth: 1.75
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs",
											children: "Supprimer"
										})]
									})
								]
							})]
						}) }, h.id))
					})]
				}, cat))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: (v) => {
					setOpen(v);
					if (!v) setEditing(null);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editing ? "Recalibrer" : "Nouvelle habitude" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: editing ? "Ajuste la règle, pas le niveau d'exigence." : "Core = pilier, 5 maximum. Le reste est secondaire — et tu choisis chaque matin ce que tu engages vraiment." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HabitForm, {
						initial: editing ?? void 0,
						onDone: () => {
							setOpen(false);
							setEditing(null);
						},
						onCancel: () => {
							setOpen(false);
							setEditing(null);
						}
					})
				] })
			})
		]
	});
}
function IconBtn({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "inline-flex h-11 min-w-11 items-center justify-center gap-1.5 rounded-md px-2.5 text-muted transition-colors duration-150 hover:bg-card-2 hover:text-foreground",
		children
	});
}
//#endregion
export { HabitsPage as component };
