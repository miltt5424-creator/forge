import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { p as useForgeStore } from "./store-KYc58Jhg.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as PageHeader } from "./bits-CgkpcfD3.mjs";
import { a as Button, n as Textarea } from "./router-BVv91lJD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identity-w9kuqNVi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function IdentityPage() {
	const identity = useForgeStore((s) => s.identity);
	const setIdentity = useForgeStore((s) => s.setIdentity);
	const resetAll = useForgeStore((s) => s.resetAll);
	const [editing, setEditing] = (0, import_react.useState)(!identity);
	const [draft, setDraft] = (0, import_react.useState)(identity);
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl forge-in",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Identité",
				title: "Qui tu deviens"
			}),
			!editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "forge-in-2 border-l-2 border-accent py-2 pl-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl font-medium uppercase leading-[1.15] tracking-[0.06em] sm:text-4xl",
					children: identity
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: draft,
					onChange: (e) => setDraft(e.target.value),
					placeholder: "Je suis un homme qui tient parole à lui-même.",
					rows: 4,
					className: "min-h-32 text-lg"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !draft.trim(),
						onClick: () => {
							setIdentity(draft);
							setEditing(false);
						},
						children: "Ancrer"
					}), identity && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => {
							setDraft(identity);
							setEditing(false);
						},
						children: "Annuler"
					})]
				})]
			}),
			!editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setEditing(true),
					children: "Recalibrer la phrase"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-12 max-w-md text-sm leading-relaxed text-muted",
				children: "Ce n'est pas une affirmation magique. C'est le standard auquel tu te tiens quand personne ne regarde."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-24 border-t border-border pt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-[0.6875rem] uppercase tracking-[0.18em] text-faint",
					children: "Zone de rupture"
				}), !confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => setConfirmReset(true),
					children: "Réinitialiser Forge"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Tout l'historique local sera effacé. Irréversible."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: resetAll,
							children: "Confirmer l'effacement"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setConfirmReset(false),
							children: "Garder"
						})]
					})]
				})]
			})
		]
	});
}
//#endregion
export { IdentityPage as component };
