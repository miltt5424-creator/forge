import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as currentWeekStart, l as isTodaySunday, p as useForgeStore, s as formatWeekRange } from "./store-KYc58Jhg.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Surface, d as heldDays, h as windowScores, r as PageHeader } from "./bits-CgkpcfD3.mjs";
import { a as Button, n as Textarea, r as Label } from "./router-BVv91lJD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/review-C4pR7Zds.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReviewPage() {
	const habits = useForgeStore((s) => s.habits);
	const mornings = useForgeStore((s) => s.mornings);
	const evenings = useForgeStore((s) => s.evenings);
	const startedAt = useForgeStore((s) => s.startedAt);
	const reviews = useForgeStore((s) => s.reviews);
	const saveReview = useForgeStore((s) => s.saveReview);
	const weekStart = currentWeekStart();
	const existing = reviews[weekStart];
	const sunday = isTodaySunday();
	const weekStats = (0, import_react.useMemo)(() => {
		const scores = windowScores(7, habits, mornings, evenings, startedAt, true);
		return heldDays(scores);
	}, [
		habits,
		mornings,
		evenings,
		startedAt
	]);
	const history = (0, import_react.useMemo)(() => Object.values(reviews).sort((a, b) => a.weekStart < b.weekStart ? 1 : -1), [reviews]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl forge-in",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Chaque dimanche",
				title: "Revue hebdomadaire",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: weekStats.total > 0 ? `${weekStats.held} jour${weekStats.held > 1 ? "s" : ""} tenu${weekStats.held > 1 ? "s" : ""} sur ${weekStats.total}` : "Pas encore de semaine à mesurer."
				})
			}),
			sunday && !existing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-6 text-sm text-foreground",
				children: "Dimanche. C'est le moment de regarder en face."
			}),
			existing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[0.6875rem] uppercase tracking-[0.18em] text-muted",
						children: ["Semaine du ", formatWeekRange(existing.weekStart)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewBlock, {
						q: "Qu'est-ce qui a tenu ?",
						a: existing.held
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewBlock, {
						q: "Qu'est-ce qui a craqué ?",
						a: existing.cracked
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewBlock, {
						q: "Est-ce que mon Standard est encore juste ?",
						a: existing.standardJust
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewBlock, {
						q: "Qu'est-ce que j'ajuste la semaine prochaine ?",
						a: existing.adjust
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewForm, {
				weekStart,
				onSave: (data) => saveReview({
					weekStart,
					...data
				})
			}),
			history.filter((r) => r.weekStart !== weekStart).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-14 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-sm uppercase tracking-[0.18em] text-muted",
					children: "Archives"
				}), history.filter((r) => r.weekStart !== weekStart).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[0.6875rem] uppercase tracking-[0.18em] text-faint",
							children: formatWeekRange(r.weekStart)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewBlock, {
							q: "Tenu",
							a: r.held
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewBlock, {
							q: "Craqué",
							a: r.cracked
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewBlock, {
							q: "Standard",
							a: r.standardJust
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewBlock, {
							q: "Ajustement",
							a: r.adjust
						})
					]
				}, r.weekStart))]
			})
		]
	});
}
function ReviewBlock({ q, a }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[0.6875rem] uppercase tracking-[0.16em] text-muted",
			children: q
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-foreground",
			children: a
		})]
	});
}
function ReviewForm({ weekStart, onSave }) {
	const [held, setHeld] = (0, import_react.useState)("");
	const [cracked, setCracked] = (0, import_react.useState)("");
	const [standardJust, setStandardJust] = (0, import_react.useState)("");
	const [adjust, setAdjust] = (0, import_react.useState)("");
	const ready = [
		held,
		cracked,
		standardJust,
		adjust
	].every((v) => v.trim());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-6",
		onSubmit: (e) => {
			e.preventDefault();
			if (!ready) return;
			onSave({
				held,
				cracked,
				standardJust,
				adjust
			});
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: ["Semaine du ", formatWeekRange(weekStart)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "held",
				label: "Qu'est-ce qui a tenu ?",
				value: held,
				onChange: setHeld
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "cracked",
				label: "Qu'est-ce qui a craqué ?",
				value: cracked,
				onChange: setCracked
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "just",
				label: "Est-ce que mon Standard est encore juste ?",
				value: standardJust,
				onChange: setStandardJust
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "adjust",
				label: "Qu'est-ce que j'ajuste la semaine prochaine ?",
				value: adjust,
				onChange: setAdjust
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "lg",
				disabled: !ready,
				children: "Clôturer la semaine"
			})
		]
	});
}
function Field({ id, label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			htmlFor: id,
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
			id,
			value,
			onChange: (e) => onChange(e.target.value),
			rows: 3
		})]
	});
}
//#endregion
export { ReviewPage as component };
