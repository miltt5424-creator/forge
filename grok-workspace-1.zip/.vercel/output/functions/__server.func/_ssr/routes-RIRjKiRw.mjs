import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as formatDayLong, c as hourOfDay, f as todayKey, i as currentWeekStart, l as isTodaySunday, p as useForgeStore, r as cn } from "./store-KYc58Jhg.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Surface, f as respectPercent, h as windowScores, i as Percent, o as activeHabits, p as secondaryHabits, r as PageHeader, s as coreHabits, t as DispersionWarning } from "./bits-CgkpcfD3.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Button, n as Textarea, r as Label } from "./router-BVv91lJD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-RIRjKiRw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FailureProtocol({ habit, remaining, onSubmit }) {
	const [why, setWhy] = (0, import_react.useState)("");
	const [correction, setCorrection] = (0, import_react.useState)("");
	const [restart, setRestart] = (0, import_react.useState)(null);
	const ready = why.trim() && correction.trim() && restart !== null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "forge-in space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[0.6875rem] uppercase tracking-[0.18em] text-muted",
						children: ["Protocole de raté", remaining > 1 ? ` · ${remaining} restants` : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-medium uppercase tracking-[0.08em]",
						children: habit.rule
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-lg text-sm leading-relaxed text-muted",
						children: "Pas de punition. Une cause, une correction, une décision."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "fail-why",
							children: "Pourquoi ça a foiré"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "fail-why",
							value: why,
							onChange: (e) => setWhy(e.target.value),
							placeholder: "La vraie raison. Pas l'excuse.",
							rows: 3
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "fail-fix",
							children: "La plus petite action corrective"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "fail-fix",
							value: correction,
							onChange: (e) => setCorrection(e.target.value),
							placeholder: "Une action que tu peux faire demain, petite.",
							rows: 3
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Est-ce que tu recommences demain ?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setRestart(true),
								className: `h-12 rounded-md text-sm font-medium transition-[background-color,box-shadow,color] duration-150 ${restart === true ? "bg-accent text-accent-foreground" : "bg-card text-muted shadow-[var(--shadow-border)] hover:text-foreground"}`,
								children: "Oui"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setRestart(false),
								className: `h-12 rounded-md text-sm font-medium transition-[background-color,box-shadow,color] duration-150 ${restart === false ? "bg-accent text-accent-foreground" : "bg-card text-muted shadow-[var(--shadow-border)] hover:text-foreground"}`,
								children: "Non"
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				className: "w-full sm:w-auto",
				disabled: !ready,
				onClick: () => onSubmit({
					why,
					correction,
					restartTomorrow: restart === true
				}),
				children: "Enregistrer"
			})
		]
	});
}
function TodayPage() {
	const habits = useForgeStore((s) => s.habits);
	const mornings = useForgeStore((s) => s.mornings);
	const evenings = useForgeStore((s) => s.evenings);
	const failures = useForgeStore((s) => s.failures);
	const identity = useForgeStore((s) => s.identity);
	const reviews = useForgeStore((s) => s.reviews);
	const startedAt = useForgeStore((s) => s.startedAt);
	const date = todayKey();
	const morning = mornings[date];
	const evening = evenings[date];
	const cores = coreHabits(habits);
	const secondaries = secondaryHabits(habits);
	const active = activeHabits(habits);
	const pendingMisses = (0, import_react.useMemo)(() => {
		if (!evening) return [];
		return (morning?.habitIds ?? []).filter((id) => evening.results[id] === false).filter((id) => !failures.some((f) => f.date === date && f.habitId === id)).map((id) => habits.find((h) => h.id === id)).filter((h) => Boolean(h));
	}, [
		evening,
		morning,
		failures,
		date,
		habits
	]);
	const s7 = (0, import_react.useMemo)(() => windowScores(7, habits, mornings, evenings, startedAt), [
		habits,
		mornings,
		evenings,
		startedAt
	]);
	const weekStart = currentWeekStart();
	const showSunday = isTodaySunday() && !reviews[weekStart];
	const hour = hourOfDay();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl forge-in",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: formatDayLong(date),
				title: "Aujourd'hui",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[0.6875rem] uppercase tracking-[0.16em] text-muted",
						children: "Standard · 7j"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl tabular-nums",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Percent, { value: respectPercent(s7, "core") })
					})]
				})
			}),
			identity && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-8 max-w-xl text-sm italic leading-relaxed text-muted",
				children: [
					"« ",
					identity,
					" »"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DispersionWarning, {}),
					showSunday && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/review",
						className: "block rounded-xl bg-card px-5 py-4 text-sm shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[0.6875rem] uppercase tracking-[0.18em] text-muted",
							children: "Dimanche"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-foreground",
							children: "La revue de la semaine n'est pas faite."
						})]
					}),
					active.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-muted",
						children: "Aucun pilier actif. Un Standard vide n'est pas de la simplicité — c'est de l'absence."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/habits",
							children: "Définir un pilier"
						})
					})] }),
					active.length > 0 && !morning && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MorningCommit, {
						date,
						cores,
						secondaries
					}),
					morning && !evening && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HonestReview, {
						date,
						habits,
						focusIds: morning.habitIds,
						late: hour >= 18
					}),
					evening && pendingMisses.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissQueue, {
						items: pendingMisses,
						date
					}),
					evening && pendingMisses.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayClosed, {
						date,
						habits,
						focusIds: morning?.habitIds ?? [],
						results: evening.results,
						reflection: evening.reflection
					})
				]
			})
		]
	});
}
function MorningCommit({ date, cores, secondaries }) {
	const commitMorning = useForgeStore((s) => s.commitMorning);
	const [selected, setSelected] = (0, import_react.useState)(() => cores.map((h) => h.id));
	function toggle(id, locked) {
		if (locked) return;
		setSelected((cur) => cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "forge-in-2 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl uppercase tracking-[0.12em]",
				children: "Engagement du jour"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-lg text-sm leading-relaxed text-muted",
				children: "Tes piliers sont déjà là. Ajoute seulement ce que tu t'engages vraiment à tenir aujourd'hui — pas ce que tu aimerais avoir fait."
			})] }),
			cores.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[0.6875rem] uppercase tracking-[0.18em] text-muted",
					children: "Piliers"
				}), cores.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectRow, {
					habit: h,
					selected: selected.includes(h.id),
					onToggle: () => toggle(h.id),
					badge: "Core"
				}, h.id))]
			}),
			secondaries.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[0.6875rem] uppercase tracking-[0.18em] text-muted",
					children: "Secondaires"
				}), secondaries.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectRow, {
					habit: h,
					selected: selected.includes(h.id),
					onToggle: () => toggle(h.id)
				}, h.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "lg",
				disabled: selected.length === 0,
				onClick: () => commitMorning(selected, date),
				children: ["Je m'engage · ", selected.length]
			})
		]
	});
}
function SelectRow({ habit, selected, onToggle, badge }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onToggle,
		className: cn("flex w-full items-start gap-4 rounded-lg bg-card px-4 py-3.5 text-left shadow-[var(--shadow-border)] transition-[box-shadow,background-color] duration-150", selected ? "shadow-[var(--shadow-border-hover)]" : "opacity-70 hover:opacity-100"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mt-0.5 size-5 shrink-0 rounded-sm border transition-colors duration-150", selected ? "border-accent bg-accent" : "border-border bg-transparent") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium text-foreground",
					children: habit.rule
				}), badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[0.625rem] uppercase tracking-[0.14em] text-faint",
					children: badge
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block text-sm text-muted",
				children: habit.why
			})]
		})]
	});
}
function HonestReview({ date, habits, focusIds, late }) {
	const closeEvening = useForgeStore((s) => s.closeEvening);
	const focus = focusIds.map((id) => habits.find((h) => h.id === id)).filter((h) => Boolean(h));
	const [results, setResults] = (0, import_react.useState)(Object.fromEntries(focusIds.map((id) => [id, null])));
	const [reflection, setReflection] = (0, import_react.useState)("");
	const allAnswered = focusIds.every((id) => results[id] !== null && results[id] !== void 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "forge-in-2 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl uppercase tracking-[0.12em]",
				children: late ? "Revue du soir" : "Revue honnête"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-lg text-sm leading-relaxed text-muted",
				children: "Pas de négociation. Fait, ou pas fait. Une phrase pour toi — pas pour un tableau."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: focus.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)] sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: h.rule
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: h.why
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Verdict, {
								active: results[h.id] === true,
								onClick: () => setResults((r) => ({
									...r,
									[h.id]: true
								})),
								children: "Fait"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Verdict, {
								active: results[h.id] === false,
								onClick: () => setResults((r) => ({
									...r,
									[h.id]: false
								})),
								children: "Pas fait"
							})]
						})
					]
				}, h.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "reflection",
					children: "Une phrase de réflexion"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "reflection",
					value: reflection,
					onChange: (e) => setReflection(e.target.value),
					placeholder: "Ce qui s'est vraiment passé.",
					rows: 3
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				disabled: !allAnswered || !reflection.trim(),
				onClick: () => {
					const locked = {};
					for (const id of focusIds) locked[id] = results[id] === true;
					closeEvening(locked, reflection, date);
				},
				children: "Clôturer la journée"
			})
		]
	});
}
function Verdict({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-12 rounded-md text-sm font-medium transition-[background-color,color] duration-150", active ? "bg-accent text-accent-foreground" : "bg-card-2 text-muted hover:text-foreground"),
		children
	});
}
function MissQueue({ items, date }) {
	const addFailure = useForgeStore((s) => s.addFailure);
	const updateHabit = useForgeStore((s) => s.updateHabit);
	const current = items[0];
	if (!current) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surface, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FailureProtocol, {
		habit: current,
		remaining: items.length,
		onSubmit: ({ why, correction, restartTomorrow }) => {
			addFailure({
				date,
				habitId: current.id,
				why,
				correction,
				restartTomorrow
			});
			if (!restartTomorrow) updateHabit(current.id, { paused: true });
		}
	}) });
}
function DayClosed({ date, habits, focusIds, results, reflection }) {
	const focus = focusIds.map((id) => habits.find((h) => h.id === id)).filter((h) => Boolean(h));
	const done = focus.filter((h) => results[h.id]).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "forge-in-2 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl uppercase tracking-[0.12em]",
				children: "Journée close"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-foreground",
						children: [
							done,
							"/",
							focus.length
						]
					}),
					" ",
					"tenues. C'est la réalité de ",
					formatDayLong(date),
					"."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: focus.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-4 rounded-lg bg-card px-4 py-3 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: h.rule
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[0.6875rem] uppercase tracking-[0.14em] text-muted",
						children: results[h.id] ? "Tenu" : "Raté"
					})]
				}, h.id))
			}),
			reflection && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "border-l-2 border-border pl-4 text-sm leading-relaxed text-muted",
				children: reflection
			})
		]
	});
}
//#endregion
export { TodayPage as component };
