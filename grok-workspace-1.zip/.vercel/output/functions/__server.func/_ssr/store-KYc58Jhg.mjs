import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as isAfter, c as startOfWeek, i as subDays, l as isSunday, o as format, r as parseISO, s as startOfDay, t as fr, u as addDays } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-KYc58Jhg.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	return crypto.randomUUID();
}
var CATEGORIES = [
	"corps",
	"esprit",
	"travail",
	"relations",
	"autre"
];
var CATEGORY_LABEL = {
	corps: "Corps",
	esprit: "Esprit",
	travail: "Travail",
	relations: "Relations",
	autre: "Autre"
};
function todayKey(now = /* @__PURE__ */ new Date()) {
	return format(now, "yyyy-MM-dd");
}
function toKey(d) {
	return format(d, "yyyy-MM-dd");
}
function fromKey(key) {
	return parseISO(`${key}T12:00:00`);
}
function formatDayLong(key) {
	return format(fromKey(key), "EEEE d MMMM", { locale: fr });
}
function formatDayShort(key) {
	return format(fromKey(key), "EEE d", { locale: fr });
}
function formatWeekRange(weekStart) {
	const start = fromKey(weekStart);
	const end = addDays(start, 6);
	return `${format(start, "d MMM", { locale: fr })} – ${format(end, "d MMM yyyy", { locale: fr })}`;
}
function currentWeekStart(now = /* @__PURE__ */ new Date()) {
	return toKey(startOfWeek(now, { weekStartsOn: 1 }));
}
function isTodaySunday(now = /* @__PURE__ */ new Date()) {
	return isSunday(now);
}
function keysBetween(startKey, endKey) {
	const keys = [];
	let cursor = fromKey(startKey);
	const end = fromKey(endKey);
	while (!isAfter(startOfDay(cursor), startOfDay(end))) {
		keys.push(toKey(cursor));
		cursor = addDays(cursor, 1);
	}
	return keys;
}
function lastNKeysIncludingToday(n, now = /* @__PURE__ */ new Date()) {
	return keysBetween(toKey(subDays(now, n - 1)), toKey(now));
}
function hourOfDay(now = /* @__PURE__ */ new Date()) {
	return now.getHours();
}
function isoDaysAgo(n) {
	return subDays(/* @__PURE__ */ new Date(), n).toISOString();
}
function keyDaysAgo(n) {
	return toKey(subDays(/* @__PURE__ */ new Date(), n));
}
function hash(s) {
	let h = 0;
	for (let i = 0; i < s.length; i++) h = h * 33 + s.charCodeAt(i) | 0;
	return Math.abs(h);
}
function exampleForge() {
	const startedAt = keyDaysAgo(27);
	const habits = [
		{
			id: uid(),
			rule: "Lever avant 6h",
			why: "Parce que la journée m'appartient si je la prends en premier.",
			tier: "core",
			category: "corps",
			rank: 0,
			paused: false,
			createdAt: isoDaysAgo(27)
		},
		{
			id: uid(),
			rule: "45 min de sport",
			why: "Parce que mon corps est l'outil. Pas un accessoire.",
			tier: "core",
			category: "corps",
			rank: 1,
			paused: false,
			createdAt: isoDaysAgo(27)
		},
		{
			id: uid(),
			rule: "20 pages de lecture",
			why: "Parce qu'un homme qui ne lit pas se répète.",
			tier: "core",
			category: "esprit",
			rank: 2,
			paused: false,
			createdAt: isoDaysAgo(27)
		},
		{
			id: uid(),
			rule: "Journal, 10 minutes",
			why: "Parce que je refuse de vivre sans me voir.",
			tier: "secondary",
			category: "esprit",
			rank: 3,
			paused: false,
			createdAt: isoDaysAgo(20)
		},
		{
			id: uid(),
			rule: "Appel à quelqu'un qui compte",
			why: "Parce que la discipline sans liens n'est qu'un isolement habillé.",
			tier: "secondary",
			category: "relations",
			rank: 4,
			paused: false,
			createdAt: isoDaysAgo(14)
		}
	];
	const mornings = {};
	const evenings = {};
	const failures = [];
	const today = todayKey();
	for (let i = 27; i >= 1; i--) {
		const date = keyDaysAgo(i);
		if (date >= today) continue;
		const available = habits.filter((h) => h.createdAt.slice(0, 10) <= date);
		const cores = available.filter((h) => h.tier === "core");
		const secondaries = available.filter((h) => h.tier === "secondary");
		const includeSecondary = hash(date + "sec") % 3 !== 0;
		const habitIds = [...cores.map((h) => h.id), ...includeSecondary ? secondaries.filter((h) => hash(date + h.id) % 2 === 0).map((h) => h.id) : []];
		mornings[date] = {
			date,
			habitIds,
			committedAt: `${date}T06:12:00.000Z`
		};
		const collapse = hash(date) % 19 === 0;
		const results = {};
		for (const id of habitIds) if (collapse) results[id] = false;
		else results[id] = hash(date + id) % 10 > 1;
		const doneCount = Object.values(results).filter(Boolean).length;
		evenings[date] = {
			date,
			results,
			reflection: collapse ? "Journée molle. J'ai négocié avec moi-même dès le matin." : doneCount === habitIds.length ? "Tenue. Rien à ajouter." : "Presque. Un pilier a lâché — pas d'excuse, une cause.",
			closedAt: `${date}T21:40:00.000Z`
		};
		for (const id of habitIds) {
			if (results[id]) continue;
			const habit = habits.find((h) => h.id === id);
			failures.push({
				id: uid(),
				date,
				habitId: id,
				why: collapse ? "Pas de structure. J'ai laissé la journée décider à ma place." : `J'ai reculé sur « ${habit?.rule ?? "cette règle"} » dès que ça a frotté.`,
				correction: "Préparer la veille. Réduire la friction à une seule action de 2 minutes.",
				restartTomorrow: true,
				createdAt: `${date}T21:45:00.000Z`
			});
		}
	}
	const reviews = {};
	const weekStarts = [
		keyDaysAgo(20),
		keyDaysAgo(13),
		keyDaysAgo(6)
	];
	const weekCopy = [
		{
			held: "Le lever et la lecture. Ça tient même les jours plats.",
			cracked: "Le sport dès que le travail déborde le soir.",
			standardJust: "Oui. Trois piliers, c'est juste. Pas plus.",
			adjust: "Sport le matin, pas en fin de journée. Couper le négociable."
		},
		{
			held: "La constance du matin. Presque sans exception.",
			cracked: "Le journal. Je le traite encore comme un luxe.",
			standardJust: "Le Standard est juste. C'est l'exécution qui flotte.",
			adjust: "Journal collé au café. Pas de téléphone avant."
		},
		{
			held: "Les piliers tiennent. Je commence à me reconnaître.",
			cracked: "Un dimanche entier lâché. Vieille habitude de 'jour off'.",
			standardJust: "Oui — et le dimanche n'est pas une exception.",
			adjust: "Protocole du dimanche : version courte, pas d'abandon."
		}
	];
	weekStarts.forEach((weekStart, i) => {
		const copy = weekCopy[i] ?? weekCopy[0];
		reviews[weekStart] = {
			weekStart,
			...copy,
			writtenAt: `${weekStart}T20:00:00.000Z`
		};
	});
	return {
		onboardingComplete: true,
		startedAt,
		identity: "Je suis un homme qui tient parole à lui-même.",
		identityUpdatedAt: isoDaysAgo(27),
		habits,
		mornings,
		evenings,
		failures,
		reviews
	};
}
var empty = {
	onboardingComplete: false,
	startedAt: null,
	identity: "",
	identityUpdatedAt: null,
	habits: [],
	mornings: {},
	evenings: {},
	failures: [],
	reviews: {}
};
function coreCount(habits, exceptId) {
	return habits.filter((h) => h.tier === "core" && !h.paused && h.id !== exceptId).length;
}
var useForgeStore = create()(persist((set, get) => ({
	...empty,
	completeOnboarding: (identity, first) => {
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const habits = first ? [{
			id: uid(),
			rule: first.rule.trim(),
			why: first.why.trim(),
			tier: first.tier,
			category: first.category,
			rank: 0,
			paused: false,
			createdAt: now
		}] : [];
		set({
			onboardingComplete: true,
			startedAt: todayKey(),
			identity: identity.trim(),
			identityUpdatedAt: now,
			habits
		});
	},
	loadExample: () => set({ ...exampleForge() }),
	setIdentity: (identity) => set({
		identity: identity.trim(),
		identityUpdatedAt: (/* @__PURE__ */ new Date()).toISOString()
	}),
	addHabit: (input) => {
		const habits = get().habits;
		if (input.tier === "core" && coreCount(habits) >= 5) return {
			ok: false,
			error: `Tes piliers sont limités à 5. Pause ou rétrograde-en un avant d'en forger un autre.`
		};
		const id = uid();
		const rank = habits.reduce((m, h) => Math.max(m, h.rank), -1) + 1;
		set({ habits: [...habits, {
			id,
			rule: input.rule.trim(),
			why: input.why.trim(),
			tier: input.tier,
			category: input.category,
			rank,
			paused: false,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		}] });
		return {
			ok: true,
			id
		};
	},
	updateHabit: (id, patch) => {
		const habits = get().habits;
		const current = habits.find((h) => h.id === id);
		if (!current) return {
			ok: false,
			error: "Habitude introuvable."
		};
		const nextTier = patch.tier ?? current.tier;
		const nextPaused = patch.paused ?? current.paused;
		if (nextTier === "core" && !nextPaused && (current.tier !== "core" || current.paused) && coreCount(habits, id) >= 5) return {
			ok: false,
			error: `Tes piliers sont limités à 5.`
		};
		set({ habits: habits.map((h) => h.id === id ? {
			...h,
			...patch
		} : h) });
		return { ok: true };
	},
	removeHabit: (id) => set({ habits: get().habits.filter((h) => h.id !== id) }),
	moveHabit: (id, dir) => {
		const habits = [...get().habits].sort((a, b) => a.rank - b.rank);
		const i = habits.findIndex((h) => h.id === id);
		const j = i + dir;
		if (i < 0 || j < 0 || j >= habits.length) return;
		const tmp = habits[i].rank;
		habits[i] = {
			...habits[i],
			rank: habits[j].rank
		};
		habits[j] = {
			...habits[j],
			rank: tmp
		};
		set({ habits });
	},
	commitMorning: (habitIds, date = todayKey()) => {
		const morning = {
			date,
			habitIds,
			committedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set({ mornings: {
			...get().mornings,
			[date]: morning
		} });
	},
	closeEvening: (results, reflection, date = todayKey()) => {
		const evening = {
			date,
			results,
			reflection: reflection.trim(),
			closedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set({ evenings: {
			...get().evenings,
			[date]: evening
		} });
	},
	addFailure: (input) => {
		const entry = {
			...input,
			id: uid(),
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set({ failures: [...get().failures, entry] });
	},
	saveReview: (input) => {
		const review = {
			...input,
			weekStart: input.weekStart || currentWeekStart(),
			writtenAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set({ reviews: {
			...get().reviews,
			[review.weekStart]: review
		} });
	},
	resetAll: () => set({ ...empty })
}), {
	name: "forge:v1",
	skipHydration: true,
	partialize: (state) => ({
		onboardingComplete: state.onboardingComplete,
		startedAt: state.startedAt,
		identity: state.identity,
		identityUpdatedAt: state.identityUpdatedAt,
		habits: state.habits,
		mornings: state.mornings,
		evenings: state.evenings,
		failures: state.failures,
		reviews: state.reviews
	})
}));
//#endregion
export { formatDayLong as a, hourOfDay as c, toKey as d, todayKey as f, currentWeekStart as i, isTodaySunday as l, CATEGORY_LABEL as n, formatDayShort as o, useForgeStore as p, cn as r, formatWeekRange as s, CATEGORIES as t, lastNKeysIncludingToday as u };
