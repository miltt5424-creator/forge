//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-tZDT1SvZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/constancy",
			"/habits",
			"/identity",
			"/review"
		],
		preloads: ["/assets/index-KaHKLJGS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-KaHKLJGS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DL_HzoIo.js", "/assets/bits-B-HRQsY0.js"]
	},
	"/constancy": {
		filePath: "/workspace/src/routes/constancy.tsx",
		children: void 0,
		preloads: ["/assets/constancy-CWw86lz7.js", "/assets/bits-B-HRQsY0.js"]
	},
	"/habits": {
		filePath: "/workspace/src/routes/habits.tsx",
		children: void 0,
		preloads: ["/assets/habits-B5qK591m.js", "/assets/bits-B-HRQsY0.js"]
	},
	"/identity": {
		filePath: "/workspace/src/routes/identity.tsx",
		children: void 0,
		preloads: ["/assets/identity-BLL4BJ-7.js", "/assets/bits-B-HRQsY0.js"]
	},
	"/review": {
		filePath: "/workspace/src/routes/review.tsx",
		children: void 0,
		preloads: ["/assets/review-DH7N1Jxw.js", "/assets/bits-B-HRQsY0.js"]
	}
} });
//#endregion
export { tsrStartManifest };
